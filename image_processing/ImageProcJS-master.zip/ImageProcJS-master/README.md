ImageProcJS
===========

Simple image processing library in JavaScript
