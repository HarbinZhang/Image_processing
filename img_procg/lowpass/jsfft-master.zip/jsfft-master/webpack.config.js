module.exports = {
  entry: "./example/index.js",
  output: {
    filename: "./example/bundle.js"
  }
}